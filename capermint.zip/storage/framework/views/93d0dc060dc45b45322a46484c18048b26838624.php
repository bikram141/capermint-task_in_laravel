

<?php $__env->startSection('content'); ?>

<div class="card m-5">
    <div class="card-header">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary"> <i class="fas fa-table me-1"></i><?php echo e($page); ?></h6>
                <a href="<?php echo e(route('category-create')); ?>" class="btn btn-dark btn-sm ">Add
                  category</a>
              </div>
    </div>
    <div class="card-body">
        <?php echo $__env->make('admin.layout.alert_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Category_title</th>
                    <th>Category_slug</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
               
                 <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->Category_title); ?></td>
                    <td><?php echo e($item->Category_slug); ?></td>
                    <td>
                        <?php if($item->Status == "Active"): ?>
                        <span class="badge text-bg-primary">Active</span>
                        <?php else: ?>
                        <span class="badge text-bg-danger">Inactive</span>
                        <?php endif; ?> 
                    </td>
                    <td>
                        <form class="deleteForm float-left"
                        action="<?php echo e(route('category-delete',$item->id)); ?>" method="post">
                        <button class="btn btn-sm btn-danger ml-2" type="submit"
                            id="deleteButton">delete
                        </button>
                        <?php echo method_field('delete'); ?>

                        <?php echo csrf_field(); ?>

                    </form>
                    <a href="<?php echo e(route('category-edit', $item->id)); ?>"
                        class="btn btn-sm  ml-2 btn-primary">edit</a>
                    </td>
                   
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </tbody> 
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capermint\capermint\resources\views/admin/category/index.blade.php ENDPATH**/ ?>