

<?php $__env->startSection('content'); ?>

<div class="card m-5">
    <div class="card-header">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary"> <i class="fas fa-table me-1"></i><?php echo e($page); ?></h6>
                <a href="<?php echo e(route('category-list')); ?>" class="btn btn-white mr-2"><i class="fa fa-arrow-left"
                    aria-hidden="true"></i> Go Back</a>
              </div>
    </div>
    <div class="card-body">
        <?php echo $__env->make('admin.layout.alert_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form class="row g-3" action="<?php echo e(route('category-update',[$category->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PUT')); ?>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="category_title"><b>Category Title</b></label>
                    <input type="text" class="form-control" id="category_title" name="Category_title"
                      placeholder="category_title" value="<?php echo e($category->Category_title); ?>">
                  </div>
            </div>

            <div class="col-md-6 mt-5">
                <div class="form-checks">
                    <label class="form-check-label mx-3" for="gridCheck">
                        Status
                      </label>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" name="Status" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="1" <?php if($category->Status == "Active"): ?> checked
                        <?php endif; ?>>
                        <label class="form-check-label" for="inlineRadio1">Active</label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" name="Status" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="0"  <?php if($category->Status == "Inactive"): ?> checked
                        <?php endif; ?>>
                        <label class="form-check-label" for="inlineRadio2">Inactive</label>
                      </div>
                    </div>
            </div>
          
            <div class="col-12">
              <button type="submit" class="btn btn-primary">update</button>
            </div>
          </form>
         
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capermint\capermint\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>