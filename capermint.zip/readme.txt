admin credentials is - admin@admin.com,
password- pasword

-------------------
api collection and database was attached with it